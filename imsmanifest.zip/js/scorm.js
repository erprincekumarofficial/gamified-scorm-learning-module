var API=null;

function findAPI(win){
  while(win){
    if(win.API) return win.API;
    win=win.parent;
  }
  return null;
}

function scormInit(){
  API=findAPI(window);
  if(API) API.LMSInitialize("");
}

function scormSetValue(key,val){
  if(API) API.LMSSetValue(key,val);
}

function scormCommit(){
  if(API) API.LMSCommit("");
}

function scormFinish(){
  if(API) API.LMSFinish("");
}