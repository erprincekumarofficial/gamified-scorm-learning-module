let points = 0;
let explored = 0;
let timelineCount = 0;

function initCourse() {
  scormInit();
  scormSetValue("cmi.core.lesson_status","incomplete");
}

function finishCourse() {
  scormCommit();
  scormFinish();
}

function addPoints(p) {
  points += p;
  document.getElementById("points").innerText = points;
  updateLevel();
}

function updateLevel() {
  let level = "Explorer";
  if(points > 50) level = "Contributor";
  if(points > 100) level = "Navigator";
  document.getElementById("level").innerText = level;
}

function updateProgress(screen) {
  let percent = (screen/6)*100;
  document.getElementById("progressBar").style.width = percent + "%";
}

function nextScreen(n) {
  document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));
  document.getElementById("screen"+n).classList.add("active");
  updateProgress(n);
}

function exploreCard(el) {
  if(!el.classList.contains("done")) {
    el.classList.add("done");
    explored++;
    addPoints(5);
    if(explored===4) document.getElementById("next2").disabled=false;
  }
}

function branch(choice) {
  let feedback = document.getElementById("branchFeedback");
  if(choice===2){
    feedback.innerText="Correct decision!";
    addPoints(20);
  } else {
    feedback.innerText="Consider long-term capability.";
    addPoints(5);
  }
}

function timeline(el){
  if(!el.classList.contains("done")){
    el.classList.add("done");
    timelineCount++;
    if(timelineCount===4){
      addPoints(15);
      document.getElementById("next4").disabled=false;
    }
  }
}

function submitQuiz(){
  let form=document.forms["quizForm"];
  let score=0;

  for(let i=1;i<=5;i++){
    let q=form["q"+i];
    for(let r of q){
      if(r.checked) score+=parseInt(r.value)*20;
    }
  }

  document.getElementById("quizResult").innerText="Score: "+score;
  scormSetValue("cmi.core.score.raw",score);

  if(score>=70){
    scormSetValue("cmi.core.lesson_status","passed");
    document.getElementById("finalMessage").innerText="Congratulations! You are a Navigator.";
  } else {
    scormSetValue("cmi.core.lesson_status","failed");
    document.getElementById("finalMessage").innerText="You may retry to improve your score.";
  }

  document.getElementById("finalPoints").innerText=points;
  scormCommit();
  nextScreen(6);
}